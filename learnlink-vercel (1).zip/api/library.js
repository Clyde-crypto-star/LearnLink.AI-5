import { put, list, del } from "@vercel/blob";

const ID = /^[\w-]{3,40}$/;

async function all(prefix) {
  let cursor, out = [];
  do {
    const r = await list({ prefix, cursor, limit: 1000 });
    out.push(...r.blobs);
    cursor = r.cursor;
  } while (cursor);
  return out;
}

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  try {
    if (req.method === "GET") {
      const since = Number(req.query.since || 0);
      const [items, gone] = await Promise.all([all("items/"), all("gone/")]);
      const latest = {}, goneAt = {};
      for (const b of items) {
        const id = b.pathname.split("/")[1], t = +new Date(b.uploadedAt);
        if (!latest[id] || t > latest[id].t) latest[id] = { t, url: b.url };
      }
      for (const b of gone) {
        const id = b.pathname.split("/")[1].replace(".json", "");
        goneAt[id] = Math.max(goneAt[id] || 0, +new Date(b.uploadedAt));
      }
      const outGone = [], out = [];
      for (const id of Object.keys(goneAt)) if (!latest[id] || goneAt[id] > latest[id].t) outGone.push(id);
      for (const [id, v] of Object.entries(latest)) {
        if (goneAt[id] && goneAt[id] > v.t) continue;
        if (v.t > since) {
          const r = await fetch(v.url);
          if (r.ok) out.push(await r.json());
        }
      }
      return res.status(200).json({ gone: outGone, items: out, now: Date.now() });
    }

    if (req.method !== "POST") return res.status(405).json({ ok: false });
    const b = req.body || {};
    const pw = process.env.ADMIN_PASSWORD;
    if (!pw || b.pw !== pw) return res.status(401).json({ ok: false });

    if (b.action === "check") return res.status(200).json({ ok: true });

    if (b.action === "save" && b.item && ID.test(b.item.id || "")) {
      const id = b.item.id, t = Date.now();
      b.item.updated = t;
      const old = await all(`items/${id}/`);
      await put(`items/${id}/${t}.json`, JSON.stringify(b.item), {
        access: "public", addRandomSuffix: false, contentType: "application/json",
      });
      if (old.length) await del(old.map((x) => x.url));
      return res.status(200).json({ ok: true, updated: t });
    }

    if (b.action === "delete" && ID.test(b.id || "")) {
      const old = await all(`items/${b.id}/`);
      if (old.length) await del(old.map((x) => x.url));
      await put(`gone/${b.id}.json`, "{}", {
        access: "public", addRandomSuffix: false, allowOverwrite: true, contentType: "application/json",
      });
      return res.status(200).json({ ok: true });
    }
    return res.status(400).json({ ok: false });
  } catch (e) {
    return res.status(500).json({ ok: false, error: String(e && e.message || e) });
  }
}
